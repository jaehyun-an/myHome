package java0508;

public class ex02_char {

	public static void main(String[] args) {
		/*// 문자형 변수타입 char(2byte)
		char ch1;
		ch1 = 'A' ;
		System.out.println('A'); //A
		System.out.println(ch1); //A
		System.out.println((int)ch1); //65
		// 문자형을 숫자로 바꿀때 변수명 앞에 (int)

		char ch2;
		ch2 = 'B' ;
		System.out.println('B'); //B
		System.out.println((int)ch2); //66
		
		char ch3;
		ch3 = 'a' ;
		System.out.println('a'); //a
		System.out.println((int)ch3); //94
		
		int num1 = 65;
		System.out.println((char)num1); //A
		// 숫자형을 문자로 바꿀때 변수명 앞에 (char)
		
		*/
		
		char ch1 = '안';
		char ch2 = '재';
		char ch3 = '현';
		System.out.println((int)ch1);
		System.out.println((int)ch2);
		System.out.println((int)ch3);
		
		int n1 = 50504;
		int n2 = 51116;
		int n3 = 54788;
		System.out.println((char)n1);
		System.out.println((char)n2);
		System.out.println((char)n3);
		

	}

}
