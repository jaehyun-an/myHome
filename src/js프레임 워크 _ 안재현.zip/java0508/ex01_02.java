/*	
Date : 08.05.2020
Author : Jaehyun
Discription : 들여쓰기 연습
Ver. 1.0
*/

package java0508;

public class ex01_02 {

	public static void main(String[] args) {

		//전체 들여쓰기 [ctrl] + [shift] + [f]

		System.out.println("들여쓰기 연습");
		System.out.println();

	}

}
