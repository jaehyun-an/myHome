package java0508;

public class ex02_day01 {
	public static void main(String[] args) {
		
		String name;
		name = "JaehyunAn";
		String birth;
		birth = "06.01";
		int age;
		age = 24;
		String adr;
		adr = "인천 서구 신현동";
		String phone;
		phone = "010-2563-5667";
		String email;
		email = "su8552@naver.com";
		String hobby;
		hobby = "travel";
		String speciality;
		speciality = "evety thing";
		String blood;
		blood = "a형";
		
		String member1;
		member1 = "eunji";
		String member2;
		member2 = "dongsun";
		String member3;
		member3 = "junhee";
		
		System.out.println("My name is " + name);
		System.out.println("My birthday is " + birth);
		System.out.println("저의 나이는 " + age + "살 입니다.");
		System.out.println("저희집 주소는 " + adr + " 입니다.");
		System.out.println("핸드폰 번호는 " + phone + " 입니다.");
		System.out.println("메일주소는 " + email + " 입니다.");
		System.out.println("취미는 " + hobby + " 입니다.");
		System.out.println("특기는 " + speciality + " 입니다.");
		System.out.println("혈액형은 " + blood + " 입니다.");
		System.out.println("팀원의 이름은 " + member1 + "입니다.");
		System.out.println("팀원의 이름은 " + member2 + "입니다.");
		System.out.println("팀원의 이름은 " + member3 + "입니다.");
		
		
		
		
		
	}
}
