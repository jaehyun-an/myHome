/*
 	Date : 08.05.2020
 	Author : Jaehyun
 	Discription : Java 기본 설정
 	Ver. 1.0
 */

/* 저장위치 찾기 = class > 우클릭 > show in > system explorar > src - 사람이 보는 파일
                                                                                        > bin - 컴퓨터가 보는 파일*/

package java0508;

public class ex01_rename {

	public static void main(String[] args) {
		
		// 주석달기
		// 1. 한 줄 주석 처리
		/* 2. 범위 주석 처리 */
		
		// ; = 문장의 마침표 역할
		
		// System.out.println(); = 화면에 표시
		System.out.println("mr.an");
		System.out.println("hello");
		
		//sysout 입력 후 [ctrl] + [space] 입력시  System.out.println();로 변경
		System.out.println();
		
		//실행(run) = [ctrl] + [F11]
		//저장(save) = [ctrl] + [s]
		//모두저장 (save all) = [ctrl] + [shift] + [s]
		
		/*클래스 이름바꾸기
		 '클래스명' 오른쪽마우스 → Refactor → Rename
		 
		 ※프로젝트, 패키지 동일
		 */
		
		
	}

}
